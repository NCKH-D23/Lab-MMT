echo "nameserver 192.168.50.53" > /etc/resolv.conf
echo "search test.lab" >> /etc/resolv.conf
